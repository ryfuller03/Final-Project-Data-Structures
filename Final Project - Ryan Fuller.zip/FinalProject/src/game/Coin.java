package game;

public class Coin {
    // Fields
    public int upgradeCost;
    public long addAmount;

    // Constructor
    public Coin() {
        this.upgradeCost = 150;
        this.addAmount = 25;
    }

    // Method
    public void upgradeCoin() {
        addAmount += 25;
        upgradeCost *= 1.5;
    }
}
