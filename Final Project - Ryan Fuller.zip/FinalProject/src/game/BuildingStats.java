package game;
import game.Buildings;

import java.util.Comparator;

public class BuildingStats {
    // Fields
    private int buildingTotalMoney;
    public int buildingMPS;
    private Buildings building;
    public int slot;

    // Constructor
    public BuildingStats(Buildings building, int slot) {
        this.building = building;
        this.buildingTotalMoney = 0;
        this.buildingMPS = building.getMPS();
        this.slot = slot;
    }

    // Methods
    public void addToBuildingTotal() {
        buildingTotalMoney += building.getMPS();
    }
    public int getBuildingTotal() {
        return buildingTotalMoney;
    }
    public int getPrice() {
        return building.getPrice();
    }
    public int getMPS() {
        return building.getMPS();
    }
    public String getBuildingName() {
        String buildingName = building.getBuilding();
        switch (buildingName) {
            case "At-Home Business ($2,000)":
                return "At-Home Business";
            case "Small Business ($5,000)":
                return "Small Business";
            case "Coffee Shop ($9,000)":
                return "Coffee Shop";
            case "Grocery Store ($15,000)":
                return "Grocery Store";
            case "Clothing Store ($25,000)":
                return "Clothing Store";
            case "Insurance Company ($50,000)":
                return "Insurance Company";
            case "Law Firm ($100,000)":
                return "Law Firm";
            case "Corporation ($1,000,000)":
                return "Corporation";


        }
        return building.getBuilding();
    }
}

