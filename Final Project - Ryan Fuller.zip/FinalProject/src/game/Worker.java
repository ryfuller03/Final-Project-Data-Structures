package game;

public class Worker {

    // Fields
    public int workerMPS = 50;
    public int numWorkers;
    public long workerCost = 100;

    // Method
    public void addWorker() {
        numWorkers += 1;
        workerCost *= 1.3;
    }

}
