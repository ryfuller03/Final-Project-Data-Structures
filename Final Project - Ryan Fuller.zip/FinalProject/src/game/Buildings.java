package game;

public enum Buildings {
    ATHOMEBUSINESS {
        @Override
        public String getBuilding() {
            return "At-Home Business ($2,000)";
        }
        int price = 2000;  // how much to buy building
        int mps = 200;  // money per second
        public int getPrice() {
            return price;
        }  // gets price for various purposes
        public int getMPS() { return mps; }  // gets money/sec for various purposes
    },

    SMALLBUSINESS {
        @Override
        public String getBuilding() {
            return "Small Business ($5,000)";
        }
        int price = 5000;
        int mps = 350;
        public int getPrice() { return price; }
        public int getMPS() { return mps; }
    },

    COFFEESHOP {
        @Override
        public String getBuilding() {
            return "Coffee Shop ($9,000)";
        }
        int price = 9000;
        int mps = 550;
        public int getPrice() { return price; }
        public int getMPS() { return mps; }
    },

    GROCERYSTORE {
        @Override
        public String getBuilding() {
            return "Grocery Store ($15,000)";
        }
        int price = 15000;
        int mps = 1000;
        public int getPrice() { return price; }
        public int getMPS() { return mps; }
    },

    CLOTHINGSTORE {
        @Override
        public String getBuilding() {
            return "Clothing Store ($25,000)";
        }
        int price = 25000;
        int mps = 1100;
        public int getPrice() { return price; }
        public int getMPS() { return mps; }
    },

    INSURANCECOMPANY {
        @Override
        public String getBuilding() {
            return "Insurance Company ($50,000)";
        }
        int price = 50000;
        int mps = 1600;
        public int getPrice() { return price; }
        public int getMPS() { return mps; }

    },
    LAWFIRM {
        @Override
        public String getBuilding() {
            return "Law Firm ($100,000)";
        }
        int price = 100000;
        int mps = 2100;
        public int getPrice() { return price; }
        public int getMPS() { return mps; }
    },

    CORPORATION {
        @Override
        public String getBuilding() {
            return "Corporation ($1,000,000)";
        }
        int price = 1000000;
        int mps = 5000;
        public int getPrice() { return price; }
        public int getMPS() { return mps; }
    };


    abstract public String getBuilding();
    abstract public int getPrice();
    abstract public int getMPS();

}
