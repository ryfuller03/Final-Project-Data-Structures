package game;
import java.util.ArrayList;

public class SortedList {
    // Fields
    public ArrayList<BuildingStats> buildingslist;

    // Constructor
    public SortedList() {
        this.buildingslist = new ArrayList<>(5);
    }

    // Methods
    public void add(BuildingStats building) {
        buildingslist.add(building);
    }

    public void remove(BuildingStats building) {
        int index = 0;
        for (int i = 0; i < 5; i++) {
            if ((buildingslist.get(i) == building) || (buildingslist.get(i).getBuildingTotal() == building.getBuildingTotal())) {
                index = i;
                break;
            }
        }
        buildingslist.remove(index);
    }

    public String compare(BuildingStats b1, BuildingStats b2) {  // returns which BuildingStats is bigger
        if (b1.getBuildingTotal() < b2.getBuildingTotal()) {
            return "b2";
        } else {
            return "b1";
        }
    }

    public void sort() {
        boolean correct = false;
        while (!correct) {
            correct = true;
            if (buildingslist.size() > 1) {
                for (int i = 0; i < (buildingslist.size()-1); i++) {
                    if (compare(buildingslist.get(i), buildingslist.get(i+1)).equals("b2")) {
                        BuildingStats temp1 = buildingslist.get(i);
                        BuildingStats temp2 = buildingslist.get(i+1);
                        buildingslist.set(i, temp2);
                        buildingslist.set((i+1), temp1);
                    }
                }
            }
        }
    }

    public void updateTotals() {
        for (BuildingStats i : buildingslist) {
            i.addToBuildingTotal();
        }
    }

    public String rankingsText() {
        if (buildingslist.size() == 0) {
            return "";
        } else if (buildingslist.size() == 1) {
            return "1. " + buildingslist.get(0).getBuildingName() + ": $" + buildingslist.get(0).getBuildingTotal();
        } else {
            String totalRankings = "";
            int placement = 0;
            for (BuildingStats i : buildingslist) {
                placement++;
                totalRankings += placement + ". " + i.getBuildingName() + ": $" + i.getBuildingTotal() + "\n";
            }
            return totalRankings;
        }
    }

    /*
    METHODS:
    - Add
    - Remove
    - Sort
     */
}
