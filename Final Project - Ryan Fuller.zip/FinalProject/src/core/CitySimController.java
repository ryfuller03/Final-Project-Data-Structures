package core;

import game.BuildingStats;
import game.Buildings;
import game.Coin;
import game.SortedList;
import javafx.animation.AnimationTimer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import java.io.File;
import java.util.Comparator;
import java.util.PriorityQueue;

public class CitySimController {

    @FXML
    private Label total;

    @FXML
    private Label overallMPSLabel;

    @FXML
    private Label numWorkers;

    @FXML
    private Label coinMPC;

    @FXML
    private Label statsReport;

    @FXML
    private Label slot1Text;

    @FXML
    private Label slot2Text;

    @FXML
    private Label slot3Text;

    @FXML
    private Label slot4Text;

    @FXML
    private Label slot5Text;

    @FXML
    private TextField advice;

    @FXML
    private Line slot1and2;

    @FXML
    private Line slot2and3;

    @FXML
    private Line slot3and4;

    @FXML
    private Line slot4and5;

    @FXML
    private Button buyWorkerButton;

    @FXML
    private Button upgradeCoinButton;

    @FXML
    private ChoiceBox<String> BuildingsBox;

    @FXML
    private ChoiceBox<String> SlotsBuyBox;

    @FXML
    private ChoiceBox<String> SlotsSellBox;

    @FXML
    private ImageView coinImage;

    @FXML
    private ImageView slot1;

    @FXML
    private ImageView slot2;

    @FXML
    private ImageView slot3;

    @FXML
    private ImageView slot4;

    @FXML
    private ImageView slot5;

    @FXML
    private ImageView cloud1;

    @FXML
    private ImageView cloud2;

    @FXML
    private ImageView cloud3;

    private Color transparent;

    private Color black;

    private boolean slotsOnScreen;

    private CitySimModel city;

    private Coin coin;

    private SortedList listofBuildings;

    private int overallMPS;

    ObservableList<String> BuildingChoices = FXCollections.observableArrayList("At-Home Business ($2,000)",
            "Small Business ($5,000)", "Coffee Shop ($9,000)", "Grocery Store ($15,000)", "Clothing Store ($25,000)",
            "Insurance Company ($50,000)", "Law Firm ($100,000)", "Corporation ($1,000,000)");
    ObservableList<String> SlotsChoices = FXCollections.observableArrayList("1", "2", "3", "4", "5");

    private class Movement extends AnimationTimer {
        private long FRAMES_PER_SEC = 50L;
        private long INTERVAL = 1000000000L / FRAMES_PER_SEC;
        private long last = 0;
        private int frame = 0;

        public void handle(long now) {
            if (now - last > INTERVAL) {
                double velocity = 1;
                cloud1.setTranslateX(cloud1.getTranslateX() + velocity);
                cloud2.setTranslateX(cloud2.getTranslateX() + velocity);
                cloud3.setTranslateX(cloud3.getTranslateX() + velocity);
                if (cloud1.getTranslateX() >= 1080) {
                    cloud1.setTranslateX(-250);
                }
                if (cloud2.getTranslateX() >= 1080) {
                    cloud2.setTranslateX(-250);
                }
                if (cloud3.getTranslateX() >= 1080) {
                    cloud3.setTranslateX(-250);
                }

                frame++;
                if (frame >= 50) {
                    updateAll();
                    listofBuildings.sort();
                    statsReport.setText(listofBuildings.rankingsText());
                    frame = 0;
                }
                last = now;
            }
        }
    }

    public void initialize() {
        this.city = new CitySimModel();
        Movement clock = new Movement();
        this.coin = new Coin();
        this.listofBuildings = new SortedList();

        this.transparent = new Color(0.0, 0.0, 0.0, 0.0); // transparent
        this.black = new Color(0.0, 0.0, 0.0, 1.0); // black

        this.slotsOnScreen = false;  // slots not showing initially

        this.BuildingsBox.setItems(BuildingChoices);  // Buildings Choice Box
        this.BuildingsBox.setValue("Choose a Building!");

        this.SlotsBuyBox.setItems(SlotsChoices);  // Slots Choice Box (BUY BUILDING)
        this.SlotsBuyBox.setValue("Which slot?");

        this.SlotsSellBox.setItems(SlotsChoices);
        this.SlotsSellBox.setValue("Which slot?");

        clock.start();  // lets mps start accumulating

        File f = new File("src/sprites/Coin.png"); // Coin Image
        coinImage.setImage(new Image(f.toURI().toString()));

        File cloudOne = new File("src/sprites/cloud1.png");  // first cloud
        cloud1.setImage(new Image(cloudOne.toURI().toString()));
        cloud1.setTranslateX(-50);

        File cloudTwo = new File("src/sprites/cloud2.png");  // second cloud
        cloud2.setImage(new Image(cloudTwo.toURI().toString()));
        cloud2.setTranslateX(350);

        File cloudThree = new File("src/sprites/cloud3.png");
        cloud3.setImage(new Image(cloudThree.toURI().toString()));
        cloud3.setTranslateX(756);

        total.setText("$" + city.totalMoney);  // Money earned
    }

    public void clickCoin() {
        city.addToTotal(coin.addAmount);
        total.setText("$" + city.totalMoney);
    }

    public void upgradeCoin() {
        if (city.totalMoney - coin.upgradeCost < 0) {
            advice.setText("You don't have enough money to upgrade your coin.");
        } else {
            city.totalMoney -= coin.upgradeCost;
            coin.upgradeCoin();
            total.setText("$" + city.totalMoney);
            upgradeCoinButton.setText("Upgrade Coin ($" + coin.upgradeCost + ")");
            coinMPC.setText("$/click: " + coin.addAmount);
            advice.setText("Upgraded coin!");
        }
    }

    public void updateAll() {
        city.addToTotal(overallMPS);
        total.setText("$" + city.totalMoney);
        listofBuildings.updateTotals();
    }

    public void buyWorker() {
        if (city.totalMoney - city.workers.workerCost < 0) {
            advice.setText("You don't have enough money to buy a worker.");
        } else {
            advice.setText("Hired worker!");
            city.buyWorker();
            buyWorkerButton.setText("Hire Worker ($" + city.workers.workerCost + ")");
            total.setText("$" + city.totalMoney);
            numWorkers.setText("Workers: " + city.workers.numWorkers);
            overallMPS += city.workers.workerMPS;
            overallMPSLabel.setText("$/sec: " + overallMPS);
        }
    }

    public void toggleSlots() {
        if (slotsOnScreen) {
            slot1and2.setStroke(transparent);
            slot2and3.setStroke(transparent);
            slot3and4.setStroke(transparent);
            slot4and5.setStroke(transparent);
            slot1Text.setText("");
            slot2Text.setText("");
            slot3Text.setText("");
            slot4Text.setText("");
            slot5Text.setText("");
            slotsOnScreen = false;
        } else {
            slot1and2.setStroke(black);
            slot2and3.setStroke(black);
            slot3and4.setStroke(black);
            slot4and5.setStroke(black);
            slot1Text.setText("1");
            slot2Text.setText("2");
            slot3Text.setText("3");
            slot4Text.setText("4");
            slot5Text.setText("5");
            slotsOnScreen = true;
        }
    }

    public void buyBuilding() {
        String buildingString = BuildingsBox.getValue();
        Buildings specBuilding = null;
        if (buildingString.equals("Choose a Building!") || SlotsBuyBox.getValue().equals("Which slot?")) {
            advice.setText("Please choose a building and a slot first!");
        } else {
            int slotNumber = Integer.parseInt(SlotsBuyBox.getValue());
            switch (buildingString) {
                case "At-Home Business ($2,000)" -> specBuilding = Buildings.ATHOMEBUSINESS;
                case "Small Business ($5,000)" -> specBuilding = Buildings.SMALLBUSINESS;
                case "Coffee Shop ($9,000)" -> specBuilding = Buildings.COFFEESHOP;
                case "Grocery Store ($15,000)" -> specBuilding = Buildings.GROCERYSTORE;
                case "Clothing Store ($25,000)" -> specBuilding = Buildings.CLOTHINGSTORE;
                case "Insurance Company ($50,000)" -> specBuilding = Buildings.INSURANCECOMPANY;
                case "Law Firm ($100,000)" -> specBuilding = Buildings.LAWFIRM;
                case "Corporation ($1,000,000)" -> specBuilding = Buildings.CORPORATION;
            }
            placeBuilding(specBuilding, slotNumber);
        }
    }

    public void placeBuilding(Buildings building, int slot) {
        if (city.totalMoney - building.getPrice() < 0) {
            advice.setText("You don't have enough money to buy this building.");
        } else if (city.buildingsOwned[slot-1] != null) {
            advice.setText("This slot is already filled.");
        } else {
            advice.setText("Your new building has been purchased in Slot " + slot + "!");
            city.totalMoney -= building.getPrice();
            city.buildingsOwned[slot-1] = new BuildingStats(building, (slot-1));
            listofBuildings.add(city.buildingsOwned[slot-1]);
            File bf = new File("src/sprites/" + building.getBuilding() + ".png");
            overallMPS += city.buildingsOwned[slot-1].getMPS();
            overallMPSLabel.setText("$/sec: " + overallMPS);
            switch (slot) {
                case 1 -> slot1.setImage(new Image(bf.toURI().toString()));
                case 2 -> slot2.setImage(new Image(bf.toURI().toString()));
                case 3 -> slot3.setImage(new Image(bf.toURI().toString()));
                case 4 -> slot4.setImage(new Image(bf.toURI().toString()));
                case 5 -> slot5.setImage(new Image(bf.toURI().toString()));
            }
        }
    }

    public void sellBuilding() {
        if (SlotsSellBox.getValue().equals("Which slot?")) {
            advice.setText("Please choose a slot to sell first!");
        } else {
            int slot = Integer.parseInt(SlotsSellBox.getValue());
            if (city.buildingsOwned[slot-1] == null) {
                advice.setText("There's no building to sell in Slot " + slot + ".");
            } else {
                city.addToTotal(city.buildingsOwned[slot - 1].getPrice() / 2);
                overallMPS -= city.buildingsOwned[slot - 1].getMPS();
                overallMPSLabel.setText("$/sec: " + overallMPS);
                listofBuildings.remove(city.buildingsOwned[slot-1]);
                city.buildingsOwned[slot - 1] = null;
                switch (slot) {
                    case 1 -> slot1.imageProperty().set(null);
                    case 2 -> slot2.imageProperty().set(null);
                    case 3 -> slot3.imageProperty().set(null);
                    case 4 -> slot4.imageProperty().set(null);
                    case 5 -> slot5.imageProperty().set(null);
                }
            }
        }
    }
}
