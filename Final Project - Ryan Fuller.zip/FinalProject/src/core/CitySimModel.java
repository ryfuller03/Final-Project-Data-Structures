package core;

import game.Worker;
import game.BuildingStats;

import java.util.PriorityQueue;

public class CitySimModel {

    public Worker workers;

    public long totalMoney;

    public BuildingStats[] buildingsOwned;

    public PriorityQueue<BuildingStats> statsQueue;

    public CitySimModel() {
        workers = new Worker();
        buildingsOwned = new BuildingStats[5];  // buildings the user has build
        for (int i = 0; i < buildingsOwned.length; i++) {
            buildingsOwned[i] = null;
        }
        statsQueue = new PriorityQueue<>();

        totalMoney = 500;  // starting value;
    }

    public void addToTotal(long amount) { totalMoney += amount; }

    public void buyWorker() {  // adds worker to total number of workers
        totalMoney -= workers.workerCost;
        workers.addWorker();
    }


}
