module FinalProject {
    requires javafx.fxml;
    requires javafx.controls;
    exports game;
    exports core;
    opens game;
    opens core;
}